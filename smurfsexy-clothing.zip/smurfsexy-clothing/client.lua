local QBCore = exports['qb-core']:GetCoreObject()

local clothingParts = {
    { id = "hats",      label = "Şapka",      type = "prop", component = 0, icon = "fa-solid fa-hat-cowboy",      anim = { dict = "missheist_agency2ahelmet", anim = "take_off_helmet_stand" }},
    { id = "masks",     label = "Maske",      type = "comp", component = 1, icon = "fa-solid fa-mask-face",      anim = { dict = "missfbi4", anim = "takeoff_mask" }},
    { id = "glasses",   label = "Gözlük",     type = "prop", component = 1, icon = "fa-solid fa-glasses",        anim = { dict = "clothingspecs", anim = "take_off" }},
    { id = "tops",      label = "Üst Giyim",  type = "comp", component = 11,icon = "fa-solid fa-shirt",          anim = { dict = "clothingtie", anim = "try_tie_neutral_b" }},
    { id = "armour",    label = "Zırh",       type = "comp", component = 9, icon = "fa-solid fa-shield-halved",  anim = { dict = "missfbi3ig_0", anim = "lift_holster_lhs" }},
    { id = "bags",      label = "Çanta",      type = "comp", component = 5, icon = "fa-solid fa-briefcase",      anim = { dict = "amb@prop_human_bum_bin@base", anim = "base" }},
    { id = "pants",     label = "Pantolon",   type = "comp", component = 4, icon = "fa-solid fa-person-military-pointing", anim = { dict = "re@construction", anim = "out_of_breath" }},
    { id = "shoes",     label = "Ayakkabı",   type = "comp", component = 6, icon = "fa-solid fa-shoe-prints",    anim = { dict = "random@domestic", anim = "pickup_low" }},
    { id = "gloves",    label = "Eldiven",    type = "comp", component = 3, icon = "fa-solid fa-mitten",         anim = { dict = "nmt_3_rcm-10", anim = "cs_nigel_dual-10" }}
}

local toggledParts = {}
local isMenuOpen = false

-- Menüyü aç/kapat
function toggleMenu()
    isMenuOpen = not isMenuOpen
    SetNuiFocus(isMenuOpen, isMenuOpen)
    SendNUIMessage({
        action = "toggleMenu",
        status = isMenuOpen,
        parts = clothingParts
    })
end

RegisterNetEvent('smurfsexy-clothing:client:openMenu', toggleMenu)

local function playAnimation(animConfig)
    if not animConfig or not animConfig.dict or not animConfig.anim then return end
    RequestAnimDict(animConfig.dict)
    while not HasAnimDictLoaded(animConfig.dict) do Wait(10) end
    TaskPlayAnim(PlayerPedId(), animConfig.dict, animConfig.anim, 8.0, -8.0, 1000, 49, 0, false, false, false)
    Wait(1000)
    ClearPedTasks(PlayerPedId())
end

local nakedParts = {
    male = {
        ['11'] = 15,  -- top
        ['8'] = 15,   -- undershirt
        ['3'] = 15,   -- arms/gloves
        ['4'] = 14,   -- pants
        ['5'] = 0,    -- bags
        ['9'] = 0,    -- armour
    },
    female = {
        ['11'] = 15,
        ['8'] = 15,
        ['3'] = 15,
        ['4'] = 15,
        ['5'] = 0,
        ['9'] = 0,
    }
}

-- UI'dan gelen talepleri işleme
RegisterNUICallback('toggle-clothing', function(data, cb)
    local ped = PlayerPedId()
    local playerSex = QBCore.Functions.GetPlayerData().charinfo.gender
    local modelKey = (playerSex == 0) and "male" or "female"
    local partInfo = nil

    for _, v in ipairs(clothingParts) do
        if v.id == data.partId then
            partInfo = v
            break
        end
    end

    if not partInfo then cb({ status = "error" }); return end

    playAnimation(partInfo.anim)

    local partKey = partInfo.id

    -- Kıyafeti Çıkar
    if not toggledParts[partKey] then
        if partInfo.type == "prop" then
            local propIndex = partInfo.component
            toggledParts[partKey] = { drawable = GetPedPropIndex(ped, propIndex), texture = GetPedPropTextureIndex(ped, propIndex) }
            ClearPedProp(ped, propIndex)
        else
            local compIndex = partInfo.component
            
            -- Geliştirilmiş Çıkarma Mantığı
            if compIndex == 11 then -- Eğer Üst Giyim çıkarılıyorsa
                -- Hem üst (11), hem içlik (8), hem de kol (3) parçasının mevcut durumunu sakla
                toggledParts[partKey] = {
                    top = { drawable = GetPedDrawableVariation(ped, 11), texture = GetPedTextureVariation(ped, 11) },
                    undershirt = { drawable = GetPedDrawableVariation(ped, 8), texture = GetPedTextureVariation(ped, 8) },
                    arms = { drawable = GetPedDrawableVariation(ped, 3), texture = GetPedTextureVariation(ped, 3) }
                }
                -- ve hepsini çıplak değerlere ayarla
                SetPedComponentVariation(ped, 11, nakedParts[modelKey]['11'], 0, 2)
                SetPedComponentVariation(ped, 8, nakedParts[modelKey]['8'], 0, 2)
                SetPedComponentVariation(ped, 3, nakedParts[modelKey]['3'], 0, 2)
            else -- Diğer kıyafetler için
                toggledParts[partKey] = { drawable = GetPedDrawableVariation(ped, compIndex), texture = GetPedTextureVariation(ped, compIndex) }
                local nakedDrawable = nakedParts[modelKey][tostring(compIndex)] or 15
                SetPedComponentVariation(ped, compIndex, nakedDrawable, 0, 2)
            end
        end
    -- Kıyafeti Geri Giydir
    else
        local saved = toggledParts[partKey]
        if partInfo.type == "prop" then
            SetPedPropIndex(ped, partInfo.component, saved.drawable, saved.texture, true)
        else
            -- Geliştirilmiş Giydirme Mantığı
            if partInfo.component == 11 then -- Eğer Üst Giyim giyiliyorsa
                SetPedComponentVariation(ped, 11, saved.top.drawable, saved.top.texture, 2)
                SetPedComponentVariation(ped, 8, saved.undershirt.drawable, saved.undershirt.texture, 2)
                SetPedComponentVariation(ped, 3, saved.arms.drawable, saved.arms.texture, 2)
            else -- Diğer kıyafetler için
                SetPedComponentVariation(ped, partInfo.component, saved.drawable, saved.texture, 2)
            end
        end
        toggledParts[partKey] = nil
    end

    cb({ status = "ok" })
end)

-- Menüyü kapatma callback'i
RegisterNUICallback('close', function(_, cb)
    toggleMenu()
    cb({ status = "ok" })
end)