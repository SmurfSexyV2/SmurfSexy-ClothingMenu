$(function() {
    window.addEventListener('message', function(event) {
        var item = event.data;
        if (item.action === 'toggleMenu') {
            if (item.status) {
                createButtons(item.parts);
                $('.menu-wrapper').show().addClass('visible');
            } else {
                $('.menu-wrapper').removeClass('visible').fadeOut(300);
            }
        }
    });

    document.onkeyup = function(data) {
        if (data.key === 'Escape') {
            closeMenu();
        }
    };

    $('#close-button').on('click', function() {
        closeMenu();
    });

    function createButtons(parts) {
        const optionsList = $('#clothing-options');
        optionsList.empty();

        parts.forEach(part => {
            const button = $(`
                <button class="clothing-button" data-partid="${part.id}">
                    <i class="${part.icon}"></i>
                    <span>${part.label}</span>
                </button>
            `);

            button.on('click', function() {
                $(this).toggleClass('toggled');
                $.post(`https://${GetParentResourceName()}/toggle-clothing`, JSON.stringify({
                    partId: part.id
                }));
            });
            
            optionsList.append($('<li>').append(button));
        });
    }

    function closeMenu() {
        $.post(`https://${GetParentResourceName()}/close`, JSON.stringify({}));
    }

    // ========== SÜRÜKLEME MANTIĞI ==========
    var isDragging = false;
    var offset = { x: 0, y: 0 };
    var menu = $('.menu-wrapper');

    // Sürüklemeyi başlat
    $('.menu-container').on('mousedown', function(e) {
        // Sadece sol tıklama ile sürüklemeyi başlat ve butonlar dışındaki alanlarda çalışsın
        if (e.button !== 0 || $(e.target).is("button, i, span")) {
            return;
        }
        isDragging = true;
        offset.x = e.pageX - menu.offset().left;
        offset.y = e.pageY - menu.offset().top;
        e.preventDefault();
    });

    // Sürükleme
    $(document).on('mousemove', function(e) {
        if (!isDragging) return;
        menu.offset({
            top: e.pageY - offset.y,
            left: e.pageX - offset.x
        });
        e.preventDefault();
    });

    // Sürüklemeyi bitir
    $(document).on('mouseup', function() {
        isDragging = false;
    });
});