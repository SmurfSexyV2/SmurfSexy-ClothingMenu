-- Bu script için sunucu taraflı bir işlem gerekmemektedir.
print("^2SmurfSexy ClothingMenü Başlatıldı.^0")